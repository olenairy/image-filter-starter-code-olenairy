
Student: Olena Chudnovets
Course: Cloud Developer
Project: Udagram Image Filtering Microservice Data: January 9 2021
Endpoint URL:  http://image-filter-starter-code-dev2222222222222.us-east-1.elasticbeanstalk.com
Git repository: https://github.com/olenairy/image-filter-starter-code-olenairy.git
